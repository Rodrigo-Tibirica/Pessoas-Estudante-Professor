package Pessoa;

import java.util.ArrayList;


public class Estudante extends Pessoa  {
	private int numCurso;
	private ArrayList<String> cursos;
	private ArrayList<Integer> notas;
	
	public Estudante(String nome, String endereco) {
		super(nome,endereco);
		this.numCurso = numCurso;
		this.cursos = new ArrayList();
		this.notas = new ArrayList();
		}

	
	public String toString() {
		String resultado = "";
		 resultado = "Estudante [numCurso=\" + numCurso + \", cursos=\" + cursos + \", notas=\" + notas + \"]";
		return resultado;
	}
	public boolean addCurso(String cursos, int notas) {
		boolean result = false;
		if(!this.cursos.contains(cursos)){
			this.notas.add(notas);
			this.cursos.add(cursos);
			return result = true;
		}
		
		return result;
		}
	
	

}
